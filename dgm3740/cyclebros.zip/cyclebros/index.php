<?php 
// required page for blog

?>