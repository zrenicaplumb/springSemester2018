</main>
		<footer>
			<nav>
				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="#">About</a></li>
					<li><a href="#">Contact</a></li>
					<li id="social"><a  href="#">Social</a></li>
				</ul>
			</nav>
		</footer>
	</body>
</html>