<ul>
						<li id="bob"><a href="#">Home</a></li>
						<li><a href="#">About</a></li>
						<li><a id="contact" href="#">Contact </a></li>
						<li><a href="#">Social</a></li>
					</ul>